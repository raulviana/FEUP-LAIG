/**
* MyTile
* @constructor
*/
class MyTile extends CGFobject {
    constructor(scene) {
        super(scene);
        this.board;
        this.piece;

    }

    getPiece(){}

    set(){}

    unset(){}

    display(){}

}